public class Teste {
 
  public static void main(String[] args) {
    Animal a = new Lobo();
    Animal b = new Peixe();
 
    a.comer();
    b.comer();
  }
}